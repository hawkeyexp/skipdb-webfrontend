<?php
include 'header.php';
echo '<div align="center">';
echo '<p><form action="index.php">';
echo '<button type="submit" style="width:524px; font-size:1.2em">>> Show Main Menu <<</button>';
echo '</form></p>';
?>
The help text will follow...
<?php
echo '<p><form action="index.php">';
echo '<button type="submit">Home</button>';
echo '</form>';
echo '</div>';
include 'footer.php';
?>
