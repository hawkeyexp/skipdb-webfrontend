<?php
echo '<div align="center">';
echo '<table>';
echo '<tr>';
echo '<td>';
echo '<form action="tools.php">';
echo '<button type="submit" class="backbutton">Back</button>';
echo '</form>';
echo '</td>';
echo '<td>';
echo '<form action="index.php">';
echo '<button type="submit">Home</button>';
echo '</form>';
echo '<td>';
echo '</tr>';
echo '<table>';
echo '</div>';
?>
