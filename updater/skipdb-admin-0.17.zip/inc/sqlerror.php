<?php
 echo mysqli_error() .": " . mysqli_errno($verbindung) . "<br>";
?>