<?php
    echo '<html>';
    echo '<meta name=viewport content="width=device-width, initial-scale=1.0">';
    echo '<head>';
    echo '<script type="text/javascript" script-name="advent-pro" src="http://use.edgefonts.net/advent-pro.js"></script>';
    echo '<script>';
    echo 'function goBack() {';
    echo '    window.history.back();';
    echo '}';
    echo '</script>';
    echo '<link async href="http://fonts.googleapis.com/css?family=Advent%20Pro" data-generated="http://enjoycss.com" rel="stylesheet" type="text/css"/>';
    echo '<link rel="stylesheet" type="text/css" href="style.css">';
    echo '</head>';
    echo '<body>';
    echo '<div align="center">';
    echo '<div class="logo" align="center"><img src="img/skipdb.png"></div>';
    echo '</div>';
?>
