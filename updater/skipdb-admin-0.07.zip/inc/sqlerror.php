<?php
 echo mysql_error() .": " . mysql_errno() . "<br>";
?>