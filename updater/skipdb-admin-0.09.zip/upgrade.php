<?php
    echo '<p class="new" style="height: auto;">You need to update you index.php for json interface!<br>It was downloaded as json.php to current folder.<br>Rename and place it as index.php!</p>';
?>
